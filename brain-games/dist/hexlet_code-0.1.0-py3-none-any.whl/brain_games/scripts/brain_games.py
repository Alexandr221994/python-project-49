#!/usr/bin/env python3
def greeting():
    print("Welcome to the Brain Games!")


if __name__ == '__main__':
    greeting()
